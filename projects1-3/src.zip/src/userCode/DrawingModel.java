 package userCode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cs355.model.drawing.CS355Drawing;
import cs355.model.drawing.Shape;

public class DrawingModel extends CS355Drawing {
	ArrayList<Shape> shapes;

	public DrawingModel() {
		shapes=new ArrayList<Shape>();
	}

	/**
	 * Get a shape at a certain index.
	 * 
	 * @param index
	 *            = the index of the desired shape.
	 * @return the shape at the provided index.
	 */
	public Shape getShape(int index){
		return shapes.get(index);
	}
	
	public void emptyModelUpdate(){
		this.setChanged();
		notifyObservers();
	}

	// Adding and deleting.

	/**
	 * Add a shape to the <b>FRONT</b> of the list.
	 * 
	 * @param s
	 *            = the shape to add.
	 * @return the index of the shape.
	 */
	public int addShape(Shape s){
		shapes.add(s);
		this.setChanged();
		notifyObservers();
		return shapes.indexOf(s);
	}

	/**
	 * Delete the shape at a certain index.
	 * 
	 * @param index
	 *            = the index of the shape to delete.
	 */
	public void deleteShape(int index){
		shapes.remove(index);
		this.setChanged();
		notifyObservers();
	}
	
	/**
	 * Delete the shape from the list if it exists
	 * 
	 * @param index
	 *            = the index of the shape to delete.
	 */
	public void deleteShape(Shape unwantedShape) {
		if(unwantedShape!=null){
			shapes.remove(unwantedShape);
		}
		
	}
	// Moving commands.

	/**
	 * Move the shape at a certain index to the front of the list.
	 * 
	 * @param index
	 *            = the index of the shape to move to the front.
	 */
	public void moveToFront(int index){
		Shape movedShape= shapes.remove(index);
		shapes.add(movedShape);
		this.setChanged();
		notifyObservers();
	}

	/**
	 * Move the shape at a certain index to the back of the list.
	 * 
	 * @param index
	 *            = the index of the shape to move to the back.
	 */
	public void movetoBack(int index){
		Shape movedshape= shapes.remove(index);
		shapes.add(0, movedshape);
		this.setChanged();
		notifyObservers();
	}

	/**
	 * Move the shape at a certain index forward one slot.
	 * 
	 * @param index
	 *            = the index of the shape to move forward.
	 */
	public void moveForward(int index){

		if((index>-1)&(index<(shapes.size()-1))){
			Collections.swap(shapes, index, index+1);
		}
		this.setChanged();
		notifyObservers();
	}
	

	/**
	 * Move the shape at a certain index backward one slot.
	 * 
	 * @param index
	 *            = the index of the shape to move backward.
	 */
	public void moveBackward(int index){
		if((index>0)&(index<shapes.size())){
			Collections.swap(shapes, index, index-1);
		}
		this.setChanged();
		notifyObservers();
	}

	// Whole list operations.

	/**
	 * Get the list of the shapes in this model.
	 * 
	 * @return the list of shapes.
	 */
	public List<Shape> getShapes(){
		return Collections.unmodifiableList(shapes);
	}

	/**
	 * Get the reversed list of the shapes in this model. This is for doing
	 * click tests (front first).
	 * 
	 * @return the reversed list of shapes.
	 */
	public List<Shape> getShapesReversed(){
		@SuppressWarnings("unchecked")
		ArrayList<Shape> inverted= (ArrayList<Shape>) shapes.clone();
		Collections.reverse(inverted);
		return Collections.unmodifiableList(inverted);
	}

	/**
	 * Sets the list of shapes in this model. This should overwrite the current
	 * list.
	 * 
	 * @param shapes
	 *            = the new list of shapes for the model.
	 */
	public void setShapes(List<Shape> shapes){
		this.shapes.clear();
		this.shapes.addAll(shapes);
		this.setChanged();
		notifyObservers();
	}
}
