package userCode;

import java.awt.geom.*;

import cs355.model.drawing.*;

public class ShapeConverter {
/*
 * Converts a shape from the model construct to a java.awt Shape, so that it can be painted onscreen more easily
 */
	public static java.awt.Shape convert(Shape currentShape) {
		if(currentShape instanceof Circle){
			java.awt.geom.Point2D.Double center=((Circle) currentShape).getCenter();
			double radius=((Circle) currentShape).getRadius();
			return new Ellipse2D.Double(center.getX()-radius, center.getY()-radius, radius*2, radius*2);
		}
		
		else if(currentShape instanceof Ellipse){
			java.awt.geom.Point2D.Double center=((Ellipse) currentShape).getCenter();
			double width=((Ellipse) currentShape).getWidth();
			double height=((Ellipse) currentShape).getHeight();
			return new Ellipse2D.Double(center.getX()-(width/2), center.getY()-(height/2), width, height);
		}
		
		else if(currentShape instanceof Line){
			java.awt.geom.Point2D.Double start=((Line) currentShape).getStart();
			java.awt.geom.Point2D.Double end=((Line) currentShape).getEnd();
			return new Line2D.Double(start, end);
		}
		
		else if(currentShape instanceof Rectangle){
			Rectangle rect=(Rectangle)currentShape;
			return new Rectangle2D.Double(rect.getUpperLeft().x,rect.getUpperLeft().y,rect.getWidth(), rect.getHeight());
		}
		
		else if(currentShape instanceof Square){
			Square sqr=(Square)currentShape;
			return new Rectangle2D.Double(sqr.getUpperLeft().x,sqr.getUpperLeft().y,sqr.getSize(), sqr.getSize());
		}
		
		else if(currentShape instanceof Triangle){
			Triangle tri=(Triangle)currentShape;
			return new java.awt.Polygon(new int[]{(int)tri.getA().x,(int)tri.getB().x,(int)tri.getC().x},
					new int[]{(int)tri.getA().y,(int)tri.getB().y,(int)tri.getC().y},3);
		}
		return null;
	}

}
