/**
 * 
 */
package userCode;

import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.util.List;
import java.util.Observable;

import cs355.GUIFunctions;
import cs355.model.drawing.*;
import cs355.view.ViewRefresher;

/**
 * @author Jordan Gates
 *
 */
public class ImplementedViewRefresher implements ViewRefresher {
	List<Shape> currentShapes;
	public ImplementedViewRefresher(CS355Drawing model) {
		model.addObserver(this);
	}

	@Override
	public void update(Observable o, Object arg) {
		;
		if(o instanceof CS355Drawing){
			currentShapes=((CS355Drawing)o).getShapes();
			GUIFunctions.refresh();
		}
	}

	@Override
	public void refreshView(Graphics2D canvas) {
		canvas.clearRect(0, 0, 3000, 3000);
		if((canvas!=null)&(currentShapes!=null)){
			for(Shape currentShape:currentShapes){
				java.awt.Shape convertedShape=ShapeConverter.convert(currentShape);
				if(convertedShape!=null){
					canvas.setColor(currentShape.getColor());
					if(convertedShape instanceof Line2D)
						canvas.draw(convertedShape);
					else
						canvas.fill(convertedShape);}
			}
		}

	}

}
